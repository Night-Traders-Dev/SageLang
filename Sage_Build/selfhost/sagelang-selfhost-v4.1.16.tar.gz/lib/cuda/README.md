# cuda

## Purpose
CUDA integration for high-performance GPGPU computing in SageLang.

## Features
- **Device Management**: Query and control CUDA devices.
- **Kernels**: Define and launch parallel kernels.
- **Memory**: Managed device memory allocation and transfers.
- **Streams**: Asynchronous execution streams.

## Usage Example
```sage
import cuda.kernel
import cuda.memory

let dev = cuda.get_device(0)
let buf = cuda.alloc(1024)
cuda.launch_kernel(my_kernel, buf, blocks=64)
```
