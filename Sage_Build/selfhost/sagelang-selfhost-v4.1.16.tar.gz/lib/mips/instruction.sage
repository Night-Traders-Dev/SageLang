## MIPS Instruction Set Definitions

class Instruction:
    proc init(op, rs, rt, rd, shamt, funct, imm, target, itype):
        self.op = op
        self.rs = rs
        self.rt = rt
        self.rd = rd
        self.shamt = shamt
        self.funct = funct
        self.imm = imm
        self.target = target
        self.itype = itype # "R", "I", "J"

# Registers maps
let REG_ZERO = 0
let REG_AT = 1
let REG_V0 = 2
let REG_V1 = 3
let REG_A0 = 4
let REG_A1 = 5
let REG_A2 = 6
let REG_A3 = 7
let REG_T0 = 8
let REG_T1 = 9
let REG_T2 = 10
let REG_T3 = 11
let REG_T4 = 12
let REG_T5 = 13
let REG_T6 = 14
let REG_T7 = 15
let REG_S0 = 16
let REG_S1 = 17
let REG_S2 = 18
let REG_S3 = 19
let REG_S4 = 20
let REG_S5 = 21
let REG_S6 = 22
let REG_S7 = 23
let REG_T8 = 24
let REG_T9 = 25
let REG_K0 = 26
let REG_K1 = 27
let REG_GP = 28
let REG_SP = 29
let REG_FP = 30
let REG_RA = 31

proc reg_name(reg):
    if reg == REG_ZERO: return "$zero"
    if reg == REG_AT: return "$at"
    if reg == REG_V0: return "$v0"
    if reg == REG_V1: return "$v1"
    if reg == REG_A0: return "$a0"
    if reg == REG_A1: return "$a1"
    if reg == REG_A2: return "$a2"
    if reg == REG_A3: return "$a3"
    if reg == REG_T0: return "$t0"
    if reg == REG_T1: return "$t1"
    if reg == REG_T2: return "$t2"
    if reg == REG_T3: return "$t3"
    if reg == REG_T4: return "$t4"
    if reg == REG_T5: return "$t5"
    if reg == REG_T6: return "$t6"
    if reg == REG_T7: return "$t7"
    if reg == REG_S0: return "$s0"
    if reg == REG_S1: return "$s1"
    if reg == REG_S2: return "$s2"
    if reg == REG_S3: return "$s3"
    if reg == REG_S4: return "$s4"
    if reg == REG_S5: return "$s5"
    if reg == REG_S6: return "$s6"
    if reg == REG_S7: return "$s7"
    if reg == REG_T8: return "$t8"
    if reg == REG_T9: return "$t9"
    if reg == REG_K0: return "$k0"
    if reg == REG_K1: return "$k1"
    if reg == REG_GP: return "$gp"
    if reg == REG_SP: return "$sp"
    if reg == REG_FP: return "$fp"
    if reg == REG_RA: return "$ra"
    return "unknown"
